drop schema if exists SuperStore;
create schema SuperStore;
use SuperStore;


create table address(
	address_id INT primary key,
	street VARCHAR(255),
	city VARCHAR(255),
	state VARCHAR(255),
	zip VARCHAR(255)
);

create table customer(
	customer_id INT primary key,
	first_name VARCHAR(255),
	last_name VARCHAR(255),
	email VARCHAR(255),
	phone VARCHAR(255),
	address_id INT,
	foreign key (address_id) references address(address_id)
);

create table warehouse(
    warehouse_id INT PRIMARY KEY,
    name VARCHAR(255),
    address_id INT,
    foreign key (address_id) REFERENCES address(address_id)
);

create table "order"(
	order_id INT primary key,
	customer_id INT,
	address_id INT,
	foreign key (customer_id) references customer(customer_id),
	foreign key (address_id) references address(address_id)
);

create table product(
	product_id INT primary key,
	product_name VARCHAR(255),
	description TEXT,
	weight DECIMAL(10, 2),
	base_cost DECIMAL(10, 2)
);

create table order_item(
	order_id INT,
	product_id INT,
	quantity INT, 
	price DECIMAL(10, 2),
	foreign key (order_id) references "order"(order_id),
	foreign key (product_id) references product(product_id)
);

create table product_warehouse(
	product_id INT,
	warehouse_id INT,
	foreign key (product_id) references product(product_id),
	foreign key (warehouse_id) references warehouse(warehouse_id)
);